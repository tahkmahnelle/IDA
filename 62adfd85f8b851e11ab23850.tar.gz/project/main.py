print("SLPOE@IDAMedia")
