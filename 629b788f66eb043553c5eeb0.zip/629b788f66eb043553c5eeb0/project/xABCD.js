console.log("Toy Magik Inc. Productions");

console.log("EHD9 SLPOE IDAMedia and Other Constitutives")

console.log("Xabcd");

// Assign values to x and a and b and c and d

let x = 24;
let a = 1;
let b = 2;
let c = 3;
let d = 4;

// Add a + b + c + d and assign y the sum value
let y = a + b + c + d;

console.log(y);
