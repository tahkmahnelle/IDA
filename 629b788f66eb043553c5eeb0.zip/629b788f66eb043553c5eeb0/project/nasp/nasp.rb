
puts "611584706866571894977"
puts "jamespattonwilson"
puts "237417411437721nass"
puts "SLPOE@IDAMedia"
